import shutil
import sys
import os.path
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import chart_studio
import chart_studio.plotly as py
import seaborn as sns
import chart_studio.plotly as py
from plotly.offline import download_plotlyjs, init_notebook_mode, plot, iplot
import folium
from folium.plugins import MarkerCluster
import json

from IPython.display import display
from geopy.geocoders import Nominatim
from geopy import distance
from pyomo.environ import *

###############################################################################
### init parameters
###############################################################################
geolocator = Nominatim(user_agent="Your_Name")

#pd.set_option('precision', 3)
MMBtu_LNG = 23.12 # 1m³ of LNG = 21.04MMBtu
MMBtu_Gas = 0.036 # 1m³ of Gas = 0.036MMBtu
LNG_to_Gas = 584 # 1m³ of LNG = 584m³ of gas (IGU LNG Annual Report 2019)
mt_LNG_BCM = 1.379 * 10**9 # mega tonne of LNG to bcm (https://www.enerdynamics.com/Energy-Currents_Blog/Understanding-Liquefied-Natural-Gas-LNG-Units.aspx)
mt_MMBtu = mt_LNG_BCM * MMBtu_Gas
t_oil_MMBtu = 39.6526 #  tonne of oil to mmbtu             https://unitjuggler.com/

import_countries = ["Japan", "China", "South Korea", "India", "Taiwan", 
                    "Pakistan", "France", "Spain","UK", "Italy", "Turkey", 
                    "Belgium", "Other Asia Pacific", "Other Europe",
                    "Total North America", "Total S. & C. America", 
                    "Total ME & Africa"
                    ]

export_countries = ["Qatar", "Australia", "USA", "Russia", "Malaysia", 
                    "Nigeria", "Trinidad & Tobago", "Algeria", "Indonesia", 
                    "Oman", "Other Asia Pacific", "Other Europe", 
                    "Other Americas", "Other ME", "Other Africa"
                    ]

###############################################################################
### 1) add Data
###############################################################################

from add_data import add_dataframes
from plots import plot_map
"""
# write data to excel file 
(
 Imp_Nodes, Exp_Nodes, 
 Distances, Distances_Suez_Closed, 
 LNG_Carrier, Additional_Costs,
 CO2, CH4,
 empty_df
) = add_dataframes()
# plot_map(Imp_Nodes, Exp_Nodes)

_data_file = "data.xlsx"
with pd.ExcelWriter(_data_file) as writer:
    Imp_Nodes.to_excel(writer, sheet_name="Imp_Nodes", index=False)
    Exp_Nodes.to_excel(writer, sheet_name="Exp_Nodes", index=False)
    Distances.to_excel(writer, sheet_name="Distances", index=True)
    Distances_Suez_Closed.to_excel(writer, sheet_name="Distances_Suez_Closed", index=True)
    LNG_Carrier.to_excel(writer, sheet_name="LNG_Carrier", index=False)
    Additional_Costs.to_excel(writer, sheet_name="Additional_Costs", index=False)
    CO2.to_excel(writer, sheet_name="CO2", index=False)
    CH4.to_excel(writer, sheet_name="CH4", index=False)
"""
# read data from excel file
_data_file = "data.xlsx"
Imp_Nodes = pd.read_excel(_data_file, sheet_name="Imp_Nodes")
Exp_Nodes = pd.read_excel(_data_file, sheet_name="Exp_Nodes")
Distances = pd.read_excel(_data_file, sheet_name="Distances", index_col=0)
Distances_Suez_Closed = pd.read_excel(_data_file, sheet_name="Distances_Suez_Closed", index_col=0)
LNG_Carrier = pd.read_excel(_data_file, sheet_name="LNG_Carrier")
Additional_Costs = pd.read_excel(_data_file, sheet_name="Additional_Costs")
CO2 = pd.read_excel(_data_file, sheet_name="CO2")
CH4 = pd.read_excel(_data_file, sheet_name="CH4")

###############################################################################
### 2) add Costs
###############################################################################
from add_data import add_costs

(
 Time, Time_Suez_Closed,
 CO2_Emissions, CH4_Emissions,
 Total_Costs
) = add_costs(Distances, Distances_Suez_Closed, LNG_Carrier, Additional_Costs, CO2, CH4)

Cost = {}
for index in Total_Costs.index:
    for column in Total_Costs.columns:
        Cost[column, index] = Total_Costs.loc[index,column]

###############################################################################
### 2) create model and solve for every month
###############################################################################
from utils import create_and_solve_model
from utils import calculate_model_results
# calculate supply and demand in every month
Supply = Exp_Nodes.set_index("Country")["Nominal Liquefaction Capacity (MMBtu)"].to_dict()
Supply_Jan = Exp_Nodes.set_index("Country")["Export Jan (MMBtu)"].to_dict()
Supply_Jun = Exp_Nodes.set_index("Country")["Export Jun (MMBtu)"].to_dict()
Supply_Aug = Exp_Nodes.set_index("Country")["Export Aug (MMBtu)"].to_dict()
Supply_Sep = Exp_Nodes.set_index("Country")["Export Sep (MMBtu)"].to_dict()
Supply_Nov = Exp_Nodes.set_index("Country")["Export Nov (MMBtu)"].to_dict()
Supply_Dec = Exp_Nodes.set_index("Country")["Export Dec (MMBtu)"].to_dict()
Supply_2019 = Exp_Nodes.set_index("Country")["Nominal Liquefaction Capacity 2019 (MMBtu)"].to_dict()
Supply_2030 = Exp_Nodes.set_index("Country")["Export 2030 (MMBtu)"].to_dict()
Supply_2040 = Exp_Nodes.set_index("Country")["Export 2040 (MMBtu)"].to_dict()
Supply_HC = Exp_Nodes.set_index("Country")["Nominal Liquefaction Capacity 2019 HC (MMBtu)"].to_dict()

Demand_Jan = Imp_Nodes.set_index("Country")["Import Jan (MMBtu)"].to_dict()
Demand_Feb = Imp_Nodes.set_index("Country")["Import Feb (MMBtu)"].to_dict()
Demand_Mar = Imp_Nodes.set_index("Country")["Import Mar (MMBtu)"].to_dict()
Demand_Apr = Imp_Nodes.set_index("Country")["Import Apr (MMBtu)"].to_dict()
Demand_May = Imp_Nodes.set_index("Country")["Import May (MMBtu)"].to_dict()
Demand_Jun = Imp_Nodes.set_index("Country")["Import Jun (MMBtu)"].to_dict()
Demand_Jul = Imp_Nodes.set_index("Country")["Import Jul (MMBtu)"].to_dict()
Demand_Aug = Imp_Nodes.set_index("Country")["Import Aug (MMBtu)"].to_dict()
Demand_Sep = Imp_Nodes.set_index("Country")["Import Sep (MMBtu)"].to_dict()
Demand_Oct = Imp_Nodes.set_index("Country")["Import Oct (MMBtu)"].to_dict()
Demand_Nov = Imp_Nodes.set_index("Country")["Import Nov (MMBtu)"].to_dict()
Demand_Dec = Imp_Nodes.set_index("Country")["Import Dec (MMBtu)"].to_dict()
Demand_2019 = Imp_Nodes.set_index("Country")["Import (MMBtu)"].to_dict()
Demand_2030 = Imp_Nodes.set_index("Country")["Import 2030 (MMBtu)"].to_dict()
Demand_2040 = Imp_Nodes.set_index("Country")["Import 2040 (MMBtu)"].to_dict()
Demand_2019_EU = Imp_Nodes.set_index("Country")["Import Europe +33% (MMBtu)"].to_dict()
Demand_2019_Asia = Imp_Nodes.set_index("Country")["Import Asia Pacific -20% (MMBtu)"].to_dict()

CUS = list(Demand_2019.keys()) 
SRC = list(Supply_2019.keys())
number_carriers = 3

###############################################################################
# January
model_2019_Jan = create_and_solve_model(Demand_Jan, Supply_Jan, Cost, number_carriers)

Import = [10.5651, 9.2547, 6.279, 2.83, 2.2386, 1.1288, 1.632, 1.42, 1.741, 1.074, 2.353, 0.585, 1.7, 1.9584, 0.911, 0.3536, 0.0952]
transported_LNG_3_Jan, DES_Price_Jan = calculate_model_results(
                                model_2019_Jan, Total_Costs, Distances, "Jan", Import)

###############################################################################
# February
model_2019_Feb = create_and_solve_model(Demand_Feb, Supply, Cost, number_carriers)

Import = [10.30575, 5.93775, 4.095, 2.56, 1.46055, 0.9248, 1.83, 1.374, 1.17, 0.93, 1.782, 0.299, 1.768, 1.8496, 0.6528, 1.02, 0.3536]
transported_LNG_3_Feb, DES_Price_Feb = calculate_model_results(
                                model_2019_Feb, Total_Costs, Distances, "Feb", Import)


###############################################################################
# March
model_2019_Mar = create_and_solve_model(Demand_Mar, Supply, Cost, number_carriers)

Import = [10.22385, 5.5419, 3.78105, 2.38, 2.0475, 1.2104, 2.335, 1.493, 1.78, 1.605, 1.4, 1.115, 2.1986, 1.6864, 0.9656, 0.9112, 0.1768]
transported_LNG_3_Mar, DES_Price_Mar = calculate_model_results(
                                model_2019_Mar, Total_Costs, Distances, "Mar", Import)

###############################################################################
# April
model_2019_Apr = create_and_solve_model(Demand_Apr, Supply, Cost, number_carriers)

Import = [7.7532, 6.1971, 3.9585, 2.62, 2.0748, 1.1832, 2.572, 1.596, 2.244, 1.115, 0.707, 0.8074, 2.2168, 2.1624, 1.02, 1.0744, 0.748]
transported_LNG_3_Apr, DES_Price_Apr = calculate_model_results(
                                model_2019_Apr, Total_Costs, Distances, "Apr", Import)

###############################################################################
# May
model_2019_May = create_and_solve_model(Demand_May, Supply, Cost, number_carriers)

Import = [7.7259, 6.04695, 4.05405, 2.75, 2.03385, 1.1152, 1.832, 1.656, 2.19, 1.115, 0.503, 0.7028, 2.9784, 2.4072, 0.9656, 1.1424, 1.4144]
transported_LNG_3_May, DES_Price_May = calculate_model_results(
                                model_2019_May, Total_Costs, Distances, "May", Import)

###############################################################################
# June
model_2019_Jun = create_and_solve_model(Demand_Jun, Supply_Jun, Cost, number_carriers)

Import = [7.7259, 6.04695, 4.05405, 2.75, 2.03385, 1.1152, 1.832, 1.656, 2.19, 1.115, 0.503, 0.7028, 2.9784, 2.4072, 0.9656, 1.1424, 1.4144]
transported_LNG_3_Jun, DES_Price_Jun = calculate_model_results(
                                model_2019_Jun, Total_Costs, Distances, "Jun", Import)

###############################################################################
# July
model_2019_Jul = create_and_solve_model(Demand_Jul, Supply, Cost, number_carriers)

Import = [7.2345, 6.18345, 4.54545, 2.73, 1.89735, 1.0744, 1.739, 1.903, 0.76, 1.387, 0.68, 0.6528, 2.0264, 2.312, 1.2784, 1.904, 1.3192]
transported_LNG_3_Jul, DES_Price_Jul = calculate_model_results(
                                model_2019_Jul, Total_Costs, Distances, "Jul", Import)

###############################################################################
# August
model_2019_Aug = create_and_solve_model(Demand_Aug, Supply_Aug, Cost, number_carriers)

Import = [8.463, 7.5075, 4.914, 2.82, 1.8837, 1.0064, 1.638, 2.144, 0.19, 1.265, 0.816, 0.9112, 2.4888, 1.9176, 1.088, 1.7408, 1.8496]
transported_LNG_3_Aug, DES_Price_Aug = calculate_model_results(
                                model_2019_Aug, Total_Costs, Distances, "Aug", Import)

###############################################################################
# September
model_2019_Sep = create_and_solve_model(Demand_Sep, Supply_Sep, Cost, number_carriers)

Import = [8.94075, 6.92055, 3.4125, 2.79, 2.0475, 0.9928, 1.2745, 2.139, 1.3, 1.13, 0.558, 0.2856, 2.3256, 1.8088, 1.0064, 1.0472, 1.5776]
transported_LNG_3_Sep, DES_Price_Sep = calculate_model_results(
                                model_2019_Sep, Total_Costs, Distances, "Sep", Import)

###############################################################################
# October
model_2019_Oct = create_and_solve_model(Demand_Oct, Supply, Cost, number_carriers)

Import = [8.85885, 5.6511, 4.368, 2.83, 2.00655, 1.0608, 1.7745, 1.95, 1.85, 1.35, 0.843, 0.7616, 2.1986, 2.0944, 0.9248, 0.8024, 1.1016]
transported_LNG_3_Oct, DES_Price_Oct = calculate_model_results(
                                model_2019_Oct, Total_Costs, Distances, "Oct", Import)

###############################################################################
# November
model_2019_Nov = create_and_solve_model(Demand_Nov, Supply_Nov, Cost, number_carriers)

Import = [8.83155, 8.66775, 5.1597, 2.79, 1.51515, 0.6664, 2.84, 1.931, 2.4, 0.94, 1.115, 1.0336, 3.876, 2.2848, 0.5984, 0.9384, 0.476]
transported_LNG_3_Nov, DES_Price_Nov = calculate_model_results(
                                model_2019_Nov, Total_Costs, Distances, "Nov", Import)

###############################################################################
# December
model_2019_Dec = create_and_solve_model(Demand_Dec, Supply_Dec, Cost, number_carriers)

Import = [9.4185, 10.30575, 6.51105, 2.83, 1.7745, 0.9792, 2.56, 1.81, 3.05, 1.1, 1.89, 0.9928, 4.148, 2.0808, 0.9656, 0.5576, 0.276]
transported_LNG_3_Dec, DES_Price_Dec = calculate_model_results(
                                model_2019_Dec, Total_Costs, Distances, "Dec", Import)

###############################################################################
### 4 Baseline (2019)
###############################################################################
### 4.1 Monthly DES Prices
###############################################################################
Des_2019 = DES_Price_Jan
Des_2019 = Des_2019.append(DES_Price_Feb)
Des_2019 = Des_2019.append(DES_Price_Mar)
Des_2019 = Des_2019.append(DES_Price_Apr)
Des_2019 = Des_2019.append(DES_Price_May)
Des_2019 = Des_2019.append(DES_Price_Jun)
Des_2019 = Des_2019.append(DES_Price_Jul)
Des_2019 = Des_2019.append(DES_Price_Aug)
Des_2019 = Des_2019.append(DES_Price_Sep)
Des_2019 = Des_2019.append(DES_Price_Oct)
Des_2019 = Des_2019.append(DES_Price_Nov)
Des_2019 = Des_2019.append(DES_Price_Dec)

ax = plt.gca()

Des_2019.plot(kind='line', y='Japan', color = 'darkred', ax=ax, figsize = (9, 6))
Des_2019.plot(kind='line',y='China', ax=ax, color = 'red')
Des_2019.plot(kind='line',y='France', ax=ax, color = 'dodgerblue')
Des_2019.plot(kind='line',y='Other Europe', ax=ax, color = 'green')
Des_2019.plot(kind='line',y='UK', ax=ax, color = 'orange')
Des_2019.plot(kind='line',y='South Korea', ax=ax, color = 'purple')
#Des_2019.plot(kind='line',y='Pakistan', ax=ax, color = 'grey')

#ax.set_xlabel(fontsize = 12)
ax.set_ylabel("$/mmBtu", fontsize = 12)
plt.legend(bbox_to_anchor=(1, 0.5))
plt.grid(axis = 'y', linestyle = '--', linewidth = 0.25)

###############################################################################
### 4.2 Monthly costs
###############################################################################
Monthly_Costs = pd.DataFrame([(round(model_2019_Jan.Cost() / 10**9, 2),
               round(model_2019_Feb.Cost() / 10**9, 2),
               round(model_2019_Mar.Cost() / 10**9, 2),
               round(model_2019_Apr.Cost() / 10**9, 2),
               round(model_2019_May.Cost() / 10**9, 2),
               round(model_2019_Jun.Cost() / 10**9, 2),
               round(model_2019_Jul.Cost() / 10**9, 2),
               round(model_2019_Aug.Cost() / 10**9, 2),
               round(model_2019_Sep.Cost() / 10**9, 2),
               round(model_2019_Oct.Cost() / 10**9, 2),
               round(model_2019_Nov.Cost() / 10**9, 2),
               round(model_2019_Dec.Cost() / 10**9, 2))],
                   
                   index = ["Monthly Costs for Imported LNG"], #"Import (MMBtu)"
    
                   columns = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
                              "Jul", "Aug","Sep", "Oct", "Nov", "Dec"]).T


ax_monthly_costs = Monthly_Costs.plot(figsize = (9, 6), kind="bar", color="lightcoral", rot=0, width=0.7)
for container in ax_monthly_costs.containers:
    ax_monthly_costs.bar_label(container)

ax_monthly_costs.set_ylabel("Billions of $")    
plt.legend(bbox_to_anchor=(1.0, 1.0))
ax_monthly_costs.get_legend().remove()
plt.show()
plt.savefig("Monthly_Costs_for_Imported_LNG.svg")

###############################################################################
### 4.3 Transported Volumes
###############################################################################
Transported_LNG_2019 = pd.DataFrame(np.zeros((len(Distances.index),len(Distances.columns))),
                   
                    index = ["Qatar", "Australia", "USA", "Russia", "Malaysia", "Nigeria",
                             "Trinidad & Tobago", "Algeria", "Indonesia", "Oman", "Other Asia Pacific",
                             "Other Europe", "Other Americas", "Other ME", "Other Africa"],

                    columns = ("Japan", "China", "South Korea", "India", "Taiwan", "Pakistan", "France",
                             "Spain","UK", "Italy", "Turkey", "Belgium", "Other Asia Pacific", "Other Europe",
                             "Total North America", "Total S. & C. America", "Total ME & Africa"))

Transported_LNG_2019 = transported_LNG_3_Jan + transported_LNG_3_Feb + transported_LNG_3_Mar + transported_LNG_3_Apr + transported_LNG_3_May + transported_LNG_3_Jun + transported_LNG_3_Jul + transported_LNG_3_Aug + transported_LNG_3_Sep + transported_LNG_3_Oct + transported_LNG_3_Nov + transported_LNG_3_Dec
Transported_LNG_2019

###############################################################################
### 4.4 LNG Shippments Table and Sankey Diagram
###############################################################################
colours_exp = ["steelblue", "orange", "mediumseagreen", "lightcoral", "purple", "peru",
           "deeppink", "gray", "gold", "turquoise", "cornflowerblue", "lime",
           "teal",  "darksalmon", "slateblue"]

colours_imp = ["crimson", "red", "lightskyblue", "saddlebrown", "lightsalmon", "seagreen",
                   "dodgerblue", "darkorange", "mediumblue", "limegreen", "darkred", "indigo",
                   "yellow", "purple", "steelblue", "seagreen", "springgreen"]

# Generate a colour pallet to let us colour in each line
palette = sns.color_palette("pastel", len(Transported_LNG_2019.index))
colours = palette.as_hex()

# Nodes & links

nodes = [['ID', 'Label', 'Color'],
         [0,'Qatar','steelblue'],
        [1,'Australia','darkorange'],
        [2,'USA','mediumseagreen'],
        [3,'Russia','lightcoral'],
        [4,'Malaysia','purple'],
        [5,'Nigeria','peru'],
        [6,'Trinidad & Tobago','deeppink'],
        [7,'Algeria','gray'],
        [8,'Indonesia','gold'],
        [9,'Oman','turquoise'],
         [10,"Other Asia Pacific",'cornflowerblue'],
         [11,"Other Europe",'sandybrown'],
         [12,'Other Americas','teal'],
         [13,'Other Middle East','darksalmon'],
         [14,'Other Africa','slateblue'], 
         [15,'Japan','crimson'], 
         [16,'China','red'],
         [17,'South Korea','lightskyblue'],
         [18,'India','saddlebrown'],
         [19,'Taiwan','lightsalmon'],
         [20,'Pakistan','seagreen'],
         [21,'France','dodgerblue'],
         [22,'Spain','darkorange'],
         [23,'UK','mediumblue'],
         [24,'Italy','limegreen'],
         [25,'Turkey','darkred'],
         [26,'Belgium','indigo'],
         [27,'Other Asia Pacific','yellow'],
         [28,'Other Europe','purple'],
         [29,'Total North America','steelblue'],
         [30,'Total S. & C. America','seagreen'],
         [31,'Total ME & Africa','springgreen'],
        ]



# links with your data
links = [['Source','Target','Value','Link Color']]

c_count = 0 #colour counter
i = 0 
j = 14

for index in Transported_LNG_2019.index:
    for column in Transported_LNG_2019.columns:
        j += 1
        if Transported_LNG_2019.loc[index, column] != 0:
            links.append([i, j, Transported_LNG_2019.loc[index, column], colours[c_count]])
            #print(i+1,",", j+1, ",", Transported_LNG_3.loc[index, column])
    i += 1
    j = 14
    c_count += 1

#links

# Retrieve headers and build dataframes
nodes_headers = nodes.pop(0)
links_headers = links.pop(0)
df_nodes = pd.DataFrame(nodes, columns = nodes_headers)
df_links = pd.DataFrame(links, columns = links_headers)

# Sankey plot setup
data_trace = dict(
    type='sankey',
    domain = dict(
      x =  [0,1],
      y =  [0,1]
    ),
    orientation = "h",
    valueformat = ".0f",
    node = dict(
      pad = 14,
     thickness = 45,
      line = dict(
        color = "black",
        width = 0
      ),
      label =  df_nodes['Label'].dropna(axis=0, how='any'),
      color = df_nodes['Color']
    ),
    link = dict(
      source = df_links['Source'].dropna(axis=0, how='any'),
      target = df_links['Target'].dropna(axis=0, how='any'),
      value = df_links['Value'].dropna(axis=0, how='any'),
      color = df_links['Link Color'].dropna(axis=0, how='any'),
  )
)

layout = dict(
              width=1000, height=1000,
              paper_bgcolor = "white",
              #title = "LNG Shipments",
              font = dict(size = 15)
             )

fig_LNG_shipment = dict(data=[data_trace], layout=layout)
iplot(fig_LNG_shipment, validate=False)
#plt.rcParams['figure.dpi'] = 200

###############################################################################
### 4.5 Number of Carriers
###############################################################################
LNG_Carrier_Number_Jan = pd.DataFrame(np.zeros((len(Distances.index),len(Distances.columns))),
                   
                    index = ["Qatar", "Australia", "USA", "Russia", "Malaysia", "Nigeria",
                             "Trinidad & Tobago", "Algeria", "Indonesia", "Oman", "Other Asia Pacific",
                             "Other Europe", "Other Americas", "Other ME", "Other Africa"],

                    columns = ("Japan", "China", "South Korea", "India", "Taiwan", "Pakistan", "France",
                             "Spain","UK", "Italy", "Turkey", "Belgium", "Other Asia Pacific", "Other Europe",
                             "Total North America", "Total S. & C. America", "Total ME & Africa"))

LNG_Carrier_Number_Feb = LNG_Carrier_Number_Mar = LNG_Carrier_Number_Apr = LNG_Carrier_Number_May = LNG_Carrier_Number_Jun = LNG_Carrier_Number_Jul = LNG_Carrier_Number_Aug = LNG_Carrier_Number_Sep = LNG_Carrier_Number_Oct = LNG_Carrier_Number_Nov = LNG_Carrier_Number_Dec = LNG_Carrier_Number_Jan

LNG_Carrier_Number_Jan = (transported_LNG_3_Jan*10**9)/(0.94 * LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas - LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas * LNG_Carrier.loc[0, "Boil off"] * Time)*(Time+3)/31
JanC = round(LNG_Carrier_Number_Jan.to_numpy().sum())

LNG_Carrier_Number_Feb = (transported_LNG_3_Feb*10**9)/(0.94 * LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas - LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas * LNG_Carrier.loc[0, "Boil off"] * Time)*(Time+3)/28
FebC = round(LNG_Carrier_Number_Feb.to_numpy().sum())

LNG_Carrier_Number_Mar = (transported_LNG_3_Mar*10**9)/(0.94 * LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas - LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas * LNG_Carrier.loc[0, "Boil off"] * Time)*(Time+3)/31
MarC = round(LNG_Carrier_Number_Mar.to_numpy().sum())

LNG_Carrier_Number_Apr = (transported_LNG_3_Apr*10**9)/(0.94 * LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas - LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas * LNG_Carrier.loc[0, "Boil off"] * Time)*(Time+3)/30
AprC = round(LNG_Carrier_Number_Apr.to_numpy().sum())

LNG_Carrier_Number_May = (transported_LNG_3_May*10**9)/(0.94 * LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas - LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas * LNG_Carrier.loc[0, "Boil off"] * Time)*(Time+3)/31
MayC = round(LNG_Carrier_Number_May.to_numpy().sum())

LNG_Carrier_Number_Jun = (transported_LNG_3_Jun*10**9)/(0.94 * LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas - LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas * LNG_Carrier.loc[0, "Boil off"] * Time)*(Time+3)/30
JunC = round(LNG_Carrier_Number_Jun.to_numpy().sum())

LNG_Carrier_Number_Jul = (transported_LNG_3_Jul*10**9)/(0.94 * LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas - LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas * LNG_Carrier.loc[0, "Boil off"] * Time)*(Time+3)/31
JulC = round(LNG_Carrier_Number_Jul.to_numpy().sum())

LNG_Carrier_Number_Aug = (transported_LNG_3_Aug*10**9)/(0.94 * LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas - LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas * LNG_Carrier.loc[0, "Boil off"] * Time)*(Time+3)/31
AugC = round(LNG_Carrier_Number_Aug.to_numpy().sum())

LNG_Carrier_Number_Sep = (transported_LNG_3_Sep*10**9)/(0.94 * LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas - LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas * LNG_Carrier.loc[0, "Boil off"] * Time)*(Time+3)/30
SepC = round(LNG_Carrier_Number_Sep.to_numpy().sum())

LNG_Carrier_Number_Oct = (transported_LNG_3_Oct*10**9)/(0.94 * LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas - LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas * LNG_Carrier.loc[0, "Boil off"] * Time)*(Time+3)/31
OctC = round(LNG_Carrier_Number_Oct.to_numpy().sum())

LNG_Carrier_Number_Nov = (transported_LNG_3_Nov*10**9)/(0.94 * LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas - LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas * LNG_Carrier.loc[0, "Boil off"] * Time)*(Time+3)/30
NovC = round(LNG_Carrier_Number_Nov.to_numpy().sum())

LNG_Carrier_Number_Dec = (transported_LNG_3_Dec*10**9)/(0.94 * LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas - LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas * LNG_Carrier.loc[0, "Boil off"] * Time)*(Time+3)/31
DecC = round(LNG_Carrier_Number_Dec.to_numpy().sum())

LNG_Carr_2019 = [JanC, FebC, MarC, AprC, MayC, JunC, JulC, AugC, SepC, OctC, NovC, DecC]


LNG_Carriers_2019 = pd.DataFrame(LNG_Carr_2019,
                   
                   index = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
                            "Jul", "Aug","Sep", "Oct", "Nov", "Dec"], #"Import (MMBtu)"
    
                   columns = ["Number of LNG Carriers"])


ax_LNG_carriers = LNG_Carriers_2019.plot(figsize = (9, 6), kind="bar", color = "orange", rot=0, width=0.7)
for container in ax_LNG_carriers.containers:
    ax_LNG_carriers.bar_label(container)
    
plt.legend(bbox_to_anchor=(1.0, 1.0))
ax_LNG_carriers.get_legend().remove()
plt.show()
#LNG_Carrier_Number_Jan
#plt.savefig("Number of LNG Carriers.svg")

###############################################################################
### 4.6 Monthly Transport Emissions 2019
###############################################################################
Emissions_CO2_Jan = (transported_LNG_3_Jan*10**9) / (0.94 * LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas - LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas * LNG_Carrier.loc[0, "Boil off"] * Time) * CO2_Emissions
Jan_CO2 = round(Emissions_CO2_Jan.to_numpy().sum()/10**6,2)

Emissions_CO2_Feb = CO2_Emissions * (transported_LNG_3_Feb*10**9) / (0.94 * LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas - LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas * LNG_Carrier.loc[0, "Boil off"] * Time)
Feb_CO2 = round(Emissions_CO2_Feb.to_numpy().sum()/10**6,2)

Emissions_CO2_Mar = CO2_Emissions * (transported_LNG_3_Mar*10**9) / (0.94 * LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas - LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas * LNG_Carrier.loc[0, "Boil off"] * Time)
Mar_CO2 = round(Emissions_CO2_Mar.to_numpy().sum()/10**6,2)

Emissions_CO2_Apr = CO2_Emissions * (transported_LNG_3_Apr*10**9) / (0.94 * LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas - LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas * LNG_Carrier.loc[0, "Boil off"] * Time)
Apr_CO2 = round(Emissions_CO2_Apr.to_numpy().sum()/10**6,2)

Emissions_CO2_May = CO2_Emissions * (transported_LNG_3_May*10**9) / (0.94 * LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas - LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas * LNG_Carrier.loc[0, "Boil off"] * Time)
May_CO2 = round(Emissions_CO2_May.to_numpy().sum()/10**6,2)

Emissions_CO2_Jun = CO2_Emissions * (transported_LNG_3_Jun*10**9) / (0.94 * LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas - LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas * LNG_Carrier.loc[0, "Boil off"] * Time)
Jun_CO2 = round(Emissions_CO2_Jun.to_numpy().sum()/10**6,2)

Emissions_CO2_Jul = CO2_Emissions * (transported_LNG_3_Jul*10**9) / (0.94 * LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas - LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas * LNG_Carrier.loc[0, "Boil off"] * Time)
Jul_CO2 = round(Emissions_CO2_Jul.to_numpy().sum()/10**6,2)

Emissions_CO2_Aug = CO2_Emissions * (transported_LNG_3_Aug*10**9) / (0.94 * LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas - LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas * LNG_Carrier.loc[0, "Boil off"] * Time)
Aug_CO2 = round(Emissions_CO2_Aug.to_numpy().sum()/10**6,2)

Emissions_CO2_Sep = CO2_Emissions * (transported_LNG_3_Sep*10**9) / (0.94 * LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas - LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas * LNG_Carrier.loc[0, "Boil off"] * Time)
Sep_CO2 = round(Emissions_CO2_Sep.to_numpy().sum()/10**6,2)

Emissions_CO2_Oct = CO2_Emissions * (transported_LNG_3_Oct*10**9) / (0.94 * LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas - LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas * LNG_Carrier.loc[0, "Boil off"] * Time)
Oct_CO2 = round(Emissions_CO2_Oct.to_numpy().sum()/10**6,2)

Emissions_CO2_Nov = CO2_Emissions * (transported_LNG_3_Nov*10**9) / (0.94 * LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas - LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas * LNG_Carrier.loc[0, "Boil off"] * Time)
Nov_CO2 = round(Emissions_CO2_Nov.to_numpy().sum()/10**6,2)

Emissions_CO2_Dec = CO2_Emissions * (transported_LNG_3_Dec*10**9) / (0.94 * LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas - LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas * LNG_Carrier.loc[0, "Boil off"] * Time)
Dec_CO2 = round(Emissions_CO2_Dec.to_numpy().sum()/10**6,2)


Emi_2019_CO2 = [Jan_CO2, Feb_CO2, Mar_CO2, Apr_CO2, May_CO2, Jun_CO2,
            Jul_CO2, Aug_CO2, Sep_CO2, Oct_CO2, Nov_CO2, Dec_CO2]

Emissions_2019_CO2 = pd.DataFrame(Emi_2019_CO2,
                   
                   index = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
                            "Jul", "Aug","Sep", "Oct", "Nov", "Dec"], #"Import (MMBtu)"
    
                   columns = ["CO2 Emissions"])


ax = Emissions_2019_CO2.plot(figsize = (9, 6), kind="bar", color = "lightgray", rot=0, width=0.7)
for container in ax.containers:
    ax.bar_label(container)

ax.set_ylabel("megatonnes")    
    
plt.legend(bbox_to_anchor=(1.0, 1.0))
ax.get_legend().remove()
plt.show()
                                           
CO2_per_mmBtu = Emissions_2019_CO2.to_numpy().sum()#/(Transported_LNG_2019.to_numpy().sum() * MMBtu_Gas * 10**3)
CO2_per_mmBtu

#Emissions_CO2_Jan

CO2_2019 = Emissions_CO2_Jan + Emissions_CO2_Feb + Emissions_CO2_Mar + Emissions_CO2_Apr + Emissions_CO2_May + Emissions_CO2_Jun + Emissions_CO2_Jul + Emissions_CO2_Aug + Emissions_CO2_Sep + Emissions_CO2_Oct + Emissions_CO2_Nov + Emissions_CO2_Dec

Emissions_CH4_Jan = CH4_Emissions * (transported_LNG_3_Jan*10**9) / (0.94 * LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas - LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas * LNG_Carrier.loc[0, "Boil off"] * Time)
Jan_CH4 = round(Emissions_CH4_Jan.to_numpy().sum()/10**3,2)

Emissions_CH4_Feb = CH4_Emissions * (transported_LNG_3_Feb*10**9) / (0.94 * LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas - LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas * LNG_Carrier.loc[0, "Boil off"] * Time)
Feb_CH4 = round(Emissions_CH4_Feb.to_numpy().sum()/10**3,2)

Emissions_CH4_Mar = CH4_Emissions * (transported_LNG_3_Mar*10**9) / (0.94 * LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas - LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas * LNG_Carrier.loc[0, "Boil off"] * Time)
Mar_CH4 = round(Emissions_CH4_Mar.to_numpy().sum()/10**3,2)

Emissions_CH4_Apr = CH4_Emissions * (transported_LNG_3_Apr*10**9) / (0.94 * LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas - LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas * LNG_Carrier.loc[0, "Boil off"] * Time)
Apr_CH4 = round(Emissions_CH4_Apr.to_numpy().sum()/10**3,2)

Emissions_CH4_May = CH4_Emissions * (transported_LNG_3_May*10**9) / (0.94 * LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas - LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas * LNG_Carrier.loc[0, "Boil off"] * Time)
May_CH4 = round(Emissions_CH4_May.to_numpy().sum()/10**3,2)

Emissions_CH4_Jun = CH4_Emissions * (transported_LNG_3_Jun*10**9) / (0.94 * LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas - LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas * LNG_Carrier.loc[0, "Boil off"] * Time)
Jun_CH4 = round(Emissions_CH4_Jun.to_numpy().sum()/10**3,2)

Emissions_CH4_Jul = CH4_Emissions * (transported_LNG_3_Jul*10**9) / (0.94 * LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas - LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas * LNG_Carrier.loc[0, "Boil off"] * Time)
Jul_CH4 = round(Emissions_CH4_Jul.to_numpy().sum()/10**3,2)

Emissions_CH4_Aug = CH4_Emissions * (transported_LNG_3_Aug*10**9) / (0.94 * LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas - LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas * LNG_Carrier.loc[0, "Boil off"] * Time)
Aug_CH4 = round(Emissions_CH4_Aug.to_numpy().sum()/10**3,2)

Emissions_CH4_Sep = CH4_Emissions * (transported_LNG_3_Sep*10**9) / (0.94 * LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas - LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas * LNG_Carrier.loc[0, "Boil off"] * Time)
Sep_CH4 = round(Emissions_CH4_Sep.to_numpy().sum()/10**3,2)

Emissions_CH4_Oct = CH4_Emissions * (transported_LNG_3_Oct*10**9) / (0.94 * LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas - LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas * LNG_Carrier.loc[0, "Boil off"] * Time)
Oct_CH4 = round(Emissions_CH4_Oct.to_numpy().sum()/10**3,2)

Emissions_CH4_Nov = CH4_Emissions * (transported_LNG_3_Nov*10**9) / (0.94 * LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas - LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas * LNG_Carrier.loc[0, "Boil off"] * Time)
Nov_CH4 = round(Emissions_CH4_Nov.to_numpy().sum()/10**3,2)

Emissions_CH4_Dec = CH4_Emissions * (transported_LNG_3_Dec*10**9) / (0.94 * LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas - LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas * LNG_Carrier.loc[0, "Boil off"] * Time)
Dec_CH4 = round(Emissions_CH4_Dec.to_numpy().sum()/10**3,2)


Emi_2019_CH4 = [Jan_CH4, Feb_CH4, Mar_CH4, Apr_CH4, May_CH4, Jun_CH4,
                Jul_CH4, Aug_CH4, Sep_CH4, Oct_CH4, Nov_CH4, Dec_CH4]

Emissions_2019_CH4 = pd.DataFrame(Emi_2019_CH4,
                   
                   index = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
                            "Jul", "Aug","Sep", "Oct", "Nov", "Dec"], #"Import (MMBtu)"
    
                   columns = ["CH4 Emissions"])


ax = Emissions_2019_CH4.plot(figsize = (9, 6), kind="bar", color = "grey", rot=0, width=0.7)
for container in ax.containers:
    ax.bar_label(container)

ax.set_ylabel("kilotonnes")    
plt.legend(bbox_to_anchor=(1.0, 1.0))
ax.get_legend().remove()
plt.show()

Emissions_2019_CH4.to_numpy().sum()

CH4_2019 = Emissions_CH4_Jan + Emissions_CH4_Feb + Emissions_CH4_Mar + Emissions_CH4_Apr + Emissions_CH4_May + Emissions_CH4_Jun + Emissions_CH4_Jul + Emissions_CH4_Aug + Emissions_CH4_Sep + Emissions_CH4_Oct + Emissions_CH4_Nov + Emissions_CH4_Dec
CH4_2019.to_numpy().sum()
#CH4_2019
CH4_per_mmBtu = Emissions_2019_CH4.to_numpy().sum()/(Transported_LNG_2019.to_numpy().sum() * MMBtu_Gas * 10**3)
CH4_per_mmBtu

###############################################################################
### 5 Shadow Prices
###############################################################################
### 5.1 Analysis by exporting nodes
###############################################################################
from utils import shadow_price_exp
Exporter_Shadow = shadow_price_exp(model_2019_Jan, SRC)
Exporter_Shadow = Exporter_Shadow.append(shadow_price_exp(model_2019_Feb, SRC))
Exporter_Shadow = Exporter_Shadow.append(shadow_price_exp(model_2019_Mar, SRC))
Exporter_Shadow = Exporter_Shadow.append(shadow_price_exp(model_2019_Apr, SRC))
Exporter_Shadow = Exporter_Shadow.append(shadow_price_exp(model_2019_May, SRC))
Exporter_Shadow = Exporter_Shadow.append(shadow_price_exp(model_2019_Jun, SRC))
Exporter_Shadow = Exporter_Shadow.append(shadow_price_exp(model_2019_Jul, SRC))
Exporter_Shadow = Exporter_Shadow.append(shadow_price_exp(model_2019_Aug, SRC))
Exporter_Shadow = Exporter_Shadow.append(shadow_price_exp(model_2019_Sep, SRC))
Exporter_Shadow = Exporter_Shadow.append(shadow_price_exp(model_2019_Oct, SRC))
Exporter_Shadow = Exporter_Shadow.append(shadow_price_exp(model_2019_Nov, SRC))
Exporter_Shadow = Exporter_Shadow.append(shadow_price_exp(model_2019_Dec, SRC))

Months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep",
          "Oct", "Nov", "Dec"]

idx = pd.Index(Months)
Exporter_Shadow = Exporter_Shadow.set_index(idx)

ax = Exporter_Shadow.plot(figsize = (9, 6), color = colours_exp)
plt.legend(bbox_to_anchor=(1.05, 0.875))
ax.set_ylabel("$/mmBtu", fontsize = 11)
plt.show()

###############################################################################
### 5.2 Analysis by importing nodes
###############################################################################
from utils import shadow_price_imp

Importer_Shadow = shadow_price_imp(model_2019_Jan, CUS)
Importer_Shadow = Importer_Shadow.append(shadow_price_imp(model_2019_Feb, CUS))
Importer_Shadow = Importer_Shadow.append(shadow_price_imp(model_2019_Mar, CUS))
Importer_Shadow = Importer_Shadow.append(shadow_price_imp(model_2019_Apr, CUS))
Importer_Shadow = Importer_Shadow.append(shadow_price_imp(model_2019_May, CUS))
Importer_Shadow = Importer_Shadow.append(shadow_price_imp(model_2019_Jun, CUS))
Importer_Shadow = Importer_Shadow.append(shadow_price_imp(model_2019_Jul, CUS))
Importer_Shadow = Importer_Shadow.append(shadow_price_imp(model_2019_Aug, CUS))
Importer_Shadow = Importer_Shadow.append(shadow_price_imp(model_2019_Sep, CUS))
Importer_Shadow = Importer_Shadow.append(shadow_price_imp(model_2019_Oct, CUS))
Importer_Shadow = Importer_Shadow.append(shadow_price_imp(model_2019_Nov, CUS))
Importer_Shadow = Importer_Shadow.append(shadow_price_imp(model_2019_Dec, CUS))
Importer_Shadow = Importer_Shadow.set_index(idx)

ax = Importer_Shadow.plot(figsize = (9, 6), color = colours_imp)
plt.legend(bbox_to_anchor=(1.05, 0.875))
ax.set_ylabel("$/mmBtu", fontsize = 11)
plt.show()

###############################################################################
### 6 Outlook
###############################################################################
### 6.1 2019
###############################################################################
model_2019 = create_and_solve_model(Demand_2019, Supply_2019, Cost, number_carriers)
CUS_2019 = list(Demand_2019.keys()) 
SRC_2019 = list(Supply_2019.keys())

Import_2019 = [105.6*10**9 * MMBtu_Gas, 84.9*10**9 * MMBtu_Gas, 55.6*10**9 * MMBtu_Gas,
                         32.9*10**9 * MMBtu_Gas, 23.2*10**9 * MMBtu_Gas, 12.4*10**9 * MMBtu_Gas,
                         23.1*10**9 * MMBtu_Gas, 21.9*10**9 * MMBtu_Gas, 19.1*10**9 * MMBtu_Gas,
                         14.3*10**9 * MMBtu_Gas, 13.2*10**9 * MMBtu_Gas, 9*10**9 * MMBtu_Gas,
                         30.6*10**9 * MMBtu_Gas, 24.4*10**9 * MMBtu_Gas, 11.2*10**9 * MMBtu_Gas,
                         13.5*10**9 * MMBtu_Gas, 10.9*10**9 * MMBtu_Gas]
transported_LNG_3_2019, DES_Price_2019 = calculate_model_results(
                                model_2019, Total_Costs, Distances, "Base Year", Import_2019)

Dual_Export_2019 = shadow_price_exp(model_2019, SRC_2019)
Dual_Import_2019 = shadow_price_imp(model_2019, CUS_2019)

###############################################################################
### 6.2 2030
###############################################################################
Cost_2030 = {}
Total_Costs_2030 = Total_Costs*1.02**11
for index in Total_Costs_2030.index:
    for column in Total_Costs_2030.columns:
        Cost_2030[column, index] = Total_Costs_2030.loc[index,column]

model_2030 = create_and_solve_model(Demand_2030, Supply_2030, Cost, number_carriers)
CUS_2030 = list(Demand_2030.keys()) 
SRC_2030 = list(Supply_2030.keys())

Import_2030 = [86.287, 135, 58.6, 55, 28.75, 51.735, 30.944, 29.379, 25.574, 19.146, 17.654, 12.093, 120, 40.776, 12.363, 14.842, 47.14]
transported_LNG_3_2030, DES_Price_2030 = calculate_model_results(
                                model_2030, Total_Costs_2030, Distances, "2030", Import_2030)

Dual_Export_2030 = shadow_price_exp(model_2030, SRC_2030)
Dual_Import_2030 = shadow_price_imp(model_2030, CUS_2030)

###############################################################################
### 6.3 2040
###############################################################################
Cost_2040 = {}
Total_Costs_2040 = Total_Costs*1.02**21
for index in Total_Costs_2040.index:
    for column in Total_Costs_2040.columns:
        Cost_2040[column, index] = Total_Costs_2040.loc[index,column]

model_2040 = create_and_solve_model(Demand_2040, Supply_2040, Cost, number_carriers)
CUS_2040 = list(Demand_2040.keys()) 
SRC_2040 = list(Supply_2040.keys())

Import_2040 = [71.84, 167.676, 62.5, 75.72, 31.25, 70.5, 40.407, 38.363, 33.395, 25.001, 23.053, 15.791, 185.391, 44.799, 13.514, 16.217, 85]
transported_LNG_3_2040, DES_Price_2040 = calculate_model_results(
                                model_2040, Total_Costs_2040, Distances, "2040", Import_2040)

Dual_Export_2040 = shadow_price_exp(model_2040, SRC_2040)
Dual_Import_2040 = shadow_price_imp(model_2040, CUS_2040)

###############################################################################
Outlook_DES = DES_Price_2019

Outlook_DES = Outlook_DES.append(DES_Price_2030)
Outlook_DES = Outlook_DES.append(DES_Price_2040)

Years = ["Base Year", "2030", "2040"]

Outlook_DES.T.plot(figsize = (9, 6), kind="bar")
plt.legend(bbox_to_anchor=(1.0, 1.0))
plt.grid(axis = 'y', linestyle = '--', linewidth = 0.25)

Outlook_Exp = pd.DataFrame([[77.1, 86, 37.8, 26.6*1.07, 30.5, 22.2, 14.8, 25.5, 26.6, 10.4, 14.1, 4.2, 4.5, 5.8, 11.3],
                            [151.69, 124.4, 150.5, 60, 43, 39.28, 17, 20, 37.7, 15.86, 20.9, 8.6, 50, 7.7, 60],
                            [173.75, 140, 220, 85, 43, 70, 17, 20, 37.7, 15.86, 20.9, 8.6, 60, 12, 100],],
                   
                    index = ["2019", "2030", "2040"],
    
                    columns = export_countries)

Outlook_Exp.loc["2030"] = Outlook_Exp.loc["2030"] * 10**9/mt_LNG_BCM
Outlook_Exp.loc["2040"] = Outlook_Exp.loc["2040"] * 10**9/mt_LNG_BCM
Outlook_Exp.plot.area(figsize = (9, 6), color = colours_exp, ylabel="mtpa", ylim=(0,800))
plt.legend(bbox_to_anchor=(1.0, 0.875))

###############################################################################
### 6.4 DES Prices Plot
###############################################################################
Imp_2019 = pd.DataFrame(np.zeros((1,len(import_countries))),         
                   index = ["Base Year"],
                   columns = import_countries)
Imp_2019.loc["Base Year"] = Import_2019
Imp_2019 *= 10**9 * MMBtu_Gas
Outlook_Imp = Imp_2019/MMBtu_Gas/mt_LNG_BCM

Imp_2030 = pd.DataFrame(np.zeros((1,len(import_countries))),         
                   index = ["2030"],
                   columns = import_countries)
Imp_2030.loc["2030"] = Import_2030
Imp_2030 *= 10**9 * MMBtu_Gas
Outlook_Imp = Outlook_Imp.append(Imp_2030/MMBtu_Gas/mt_LNG_BCM)

Imp_2040 = pd.DataFrame(np.zeros((1,len(import_countries))),         
                   index = ["2040"],
                   columns = import_countries)
Imp_2040.loc["2040"] = Import_2040
Imp_2040 *= 10**9 * MMBtu_Gas
Outlook_Imp = Outlook_Imp.append(Imp_2040/MMBtu_Gas/mt_LNG_BCM)
Outlook_Imp.plot.area(figsize = (9, 6), color = colours_imp, ylabel="mtpa", ylim=(0,800))
plt.legend(bbox_to_anchor=(1.0, 0.915))

###############################################################################
### 6.5 Importers Shadowprices Outlook
###############################################################################
Outlook_Importer_Shadow = Dual_Import_2019

Outlook_Importer_Shadow = Outlook_Importer_Shadow.append(Dual_Import_2030)
Outlook_Importer_Shadow = Outlook_Importer_Shadow.append(Dual_Import_2040)

id_y = pd.Index(Years)
Outlook_Importer_Shadow = Outlook_Importer_Shadow.set_index(id_y)

Outlook_Importer_Shadow.T.plot(figsize = (9, 6), kind="bar")
plt.legend(bbox_to_anchor=(1.0, 1.0))

###############################################################################
### 6.6 Costs Outlook
###############################################################################
Total_Costs_2019 = model_2019_Jan.Cost() + model_2019_Feb.Cost() + model_2019_Mar.Cost() + model_2019_Apr.Cost() + model_2019_May.Cost() + model_2019_Jun.Cost() + model_2019_Jul.Cost() + model_2019_Aug.Cost() + model_2019_Sep.Cost() + model_2019_Oct.Cost() + model_2019_Nov.Cost() + model_2019_Dec.Cost()

Imports_Outlook = [round(Imp_Nodes["Import (MMBtu)"].sum() / 10**9 / MMBtu_Gas,0),
                   round(Imp_Nodes["Import 2030 (MMBtu)"].sum() / 10**9 / MMBtu_Gas,0),
                   round(Imp_Nodes["Import 2040 (MMBtu)"].sum() / 10**9 / MMBtu_Gas,0)]

Total_Costs_Out = [round(Total_Costs_2019  / 10**9, 0),
               round(model_2030.Cost() / 10**9, 0),
               round(model_2040.Cost() / 10**9, 0)]

Total_Costs_Outlook = pd.DataFrame({#"Import Volumes": Imports_Outlook, 
                                    "Total Costs": Total_Costs_Out}, 
                                   index = ["2019", "2030", "2040"])

ax = Total_Costs_Outlook.plot(figsize = (9, 6), kind="bar", color = [#"lightblue",
                                                                     "lightcoral"], rot=0)
for container in ax.containers:
    ax.bar_label(container)
ax.set_ylabel("Billions of $")    
        
plt.legend(bbox_to_anchor=(1.0, 1.0))
ax.get_legend().remove()
#ax.set_xlabel("Minimal number of different importing routes")
plt.show()

###############################################################################
### 6.7 Number of Carriers Outlook
###############################################################################
LNG_Carrier_Number_2030 = pd.DataFrame(np.zeros((len(Distances.index),len(Distances.columns))),
                    index = export_countries,
                    columns = import_countries)

LNG_Carrier_Number_2040 = pd.DataFrame(np.zeros((len(Distances.index),len(Distances.columns))),
                    index = export_countries,
                    columns = import_countries)

LNG_Carrier_Number_2019 = pd.DataFrame(np.zeros((len(Distances.index),len(Distances.columns))),
                    index = export_countries,
                    columns = import_countries)

LNG_Carrier_Number_2030 = (transported_LNG_3_2030*10**9)/(0.94 * LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas - LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas * LNG_Carrier.loc[0, "Boil off"] * Time)*(Time+3)/365
Carriers_2030 = round(LNG_Carrier_Number_2030.to_numpy().sum())

LNG_Carrier_Number_2019 = (transported_LNG_3_2019*10**9)/(0.94 * LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas - LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas * LNG_Carrier.loc[0, "Boil off"] * Time)*(Time+3)/365
Carriers_2019 = round(LNG_Carrier_Number_2019.to_numpy().sum())

LNG_Carrier_Number_2040 = (transported_LNG_3_2040*10**9)/(0.94 * LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas - LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas * LNG_Carrier.loc[0, "Boil off"] * Time)*(Time+3)/366
Carriers_2040 = round(LNG_Carrier_Number_2040.to_numpy().sum())

LNG_Carr_Outlook = [Carriers_2019, Carriers_2030, Carriers_2040]

LNG_Carriers_ = pd.DataFrame({"Number of LNG Carriers": LNG_Carr_Outlook, 
                              }, index = ["2019", "2030", "2040"])


ax = LNG_Carriers_.plot(figsize = (9, 6), kind="bar", color = ["orange", "coral"], rot=0)

for container in ax.containers:
    ax.bar_label(container)
    
plt.legend(bbox_to_anchor=(1.0, 1.0))
ax.get_legend().remove()
plt.show()

###############################################################################
### 6.8 Emissions Outlook
###############################################################################
Emissions_2019_ = CO2_Emissions * (transported_LNG_3_2019*10**9) / (0.94 * LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas - LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas * LNG_Carrier.loc[0, "Boil off"] * Time)
Outlook_2019_CO2 = round(Emissions_2019_.to_numpy().sum()/10**6,2)

Emissions_2030_ = CO2_Emissions * (transported_LNG_3_2030*10**9) / (0.94 * LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas - LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas * LNG_Carrier.loc[0, "Boil off"] * Time)
Outlook_2030_CO2 = round(Emissions_2030_.to_numpy().sum()/10**6,2)

Emissions_2040_ = CO2_Emissions * (transported_LNG_3_2040*10**9) / (0.94 * LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas - LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas * LNG_Carrier.loc[0, "Boil off"] * Time)
Outlook_2040_CO2 = round(Emissions_2040_.to_numpy().sum()/10**6,2)

Emi_Outlook_CO2 = [Outlook_2019_CO2, Outlook_2030_CO2, Outlook_2040_CO2]

Emissions_Outlook_CO2 = pd.DataFrame(Emi_Outlook_CO2,
                   
                   index = ["2019", "2030", "2040"],
    
                   columns = ["CO2 Emissions"])


ax = Emissions_Outlook_CO2.plot(figsize = (9, 6), kind="bar", color = "lightgray", rot=0)
for container in ax.containers:
    ax.bar_label(container)

ax.set_ylabel("megatonnes")    
plt.legend(bbox_to_anchor=(1.0, 1.0))
ax.get_legend().remove()
plt.show()
CO2_per_mmBtu_2040 = Emissions_2040_.to_numpy().sum()/(transported_LNG_3_2040.to_numpy().sum() * MMBtu_Gas * 10**9)
Outlook_2019_CO2

Emissions_2019__ = CH4_Emissions * (transported_LNG_3_2019*10**9) / (0.94 * LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas - LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas * LNG_Carrier.loc[0, "Boil off"] * Time)
Outlook_2019_CH4 = round(Emissions_2019__.to_numpy().sum()/10**3,2)

Emissions_2030__ = CH4_Emissions * (transported_LNG_3_2030*10**9) / (0.94 * LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas - LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas * LNG_Carrier.loc[0, "Boil off"] * Time)
Outlook_2030_CH4 = round(Emissions_2030__.to_numpy().sum()/10**3,2)

Emissions_2040__ = CH4_Emissions * (transported_LNG_3_2040*10**9) / (0.94 * LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas - LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas * LNG_Carrier.loc[0, "Boil off"] * Time)
Outlook_2040_CH4 = round(Emissions_2040__.to_numpy().sum()/10**3,2)

Emi_Outlook_CH4 = [Outlook_2019_CH4, Outlook_2030_CH4, Outlook_2040_CH4]

Emissions_Outlook_CH4 = pd.DataFrame(Emi_Outlook_CH4,
                   
                   index = ["2019", "2030", "2040"],
    
                   columns = ["CH4 Emissions"])


ax = Emissions_Outlook_CH4.plot(figsize = (9, 6), kind="bar", color = "grey", rot=0)
for container in ax.containers:
    ax.bar_label(container)

ax.set_ylabel("kilotonnes")    
plt.legend(bbox_to_anchor=(1.0, 1.0))
ax.get_legend().remove()
plt.show()

###############################################################################
### 7 Diversification of importing routes
###############################################################################
### 7.1 4 Suppliers
###############################################################################
number_carriers = 4

model_2019_4_Suppliers = create_and_solve_model(Demand_2019, Supply_2019, Cost, number_carriers)
CUS_2019 = list(Demand_2019.keys()) 
SRC_2019 = list(Supply_2019.keys())

transported_LNG_2019_4_Suppliers, DES_Price_2019_4_Suppliers = calculate_model_results(
                                model_2019_4_Suppliers, Total_Costs, Distances, "Base Year", Import_2019)

###############################################################################
### 7.2 5 Suppliers
###############################################################################
number_carriers = 4.524886877828054

model_2019_5_Suppliers = create_and_solve_model(Demand_2019, Supply_2019, Cost, number_carriers)
CUS_2019 = list(Demand_2019.keys()) 
SRC_2019 = list(Supply_2019.keys())

transported_LNG_2019_5_Suppliers, DES_Price_2019_5_Suppliers = calculate_model_results(
                                model_2019_5_Suppliers, Total_Costs, Distances, "Base Year", Import_2019)

###############################################################################
### 7.3 Shadow prices
###############################################################################
Dual_Export_2019_4 = shadow_price_exp(model_2019_4_Suppliers, SRC_2019)
Dual_Import_2019_4 = shadow_price_imp(model_2019_4_Suppliers, CUS_2019)

Dual_Export_2019_5 = shadow_price_exp(model_2019_5_Suppliers, SRC_2019)
Dual_Import_2019_5 = shadow_price_imp(model_2019_5_Suppliers, CUS_2019)

###############################################################################
### 7.4 DES Prices Plot
###############################################################################
Diver_DES = DES_Price_2019

Diver_DES = Diver_DES.append(DES_Price_2019_4_Suppliers)
Diver_DES = Diver_DES.append(DES_Price_2019_5_Suppliers)

Diver_DESv_Num = ["3 Exporters", "4 Exporters", "5 Exporters"]

id_y = pd.Index(Diver_DESv_Num)
Diver_DES = Diver_DES.set_index(id_y)

Diver_DES.T.plot(figsize = (9, 6), kind="bar")
#plt.legend(bbox_to_anchor=(1.0, 1.0))
plt.grid(axis = 'y', linestyle = '--', linewidth = 0.25)

###############################################################################
### 7.5 Tankers Number
###############################################################################
num_carrier_3 = pd.DataFrame(np.zeros((len(Distances.index),len(Distances.columns))),
                    index = export_countries,
                    columns = import_countries)

num_carrier_3 = (Transported_LNG_2019*10**9)/(0.94 * LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas - LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas * LNG_Carrier.loc[0, "Boil off"] * Time)*(Time+3)/365
num_carrier_3.to_numpy().sum()

num_carrier_2019_4_Suppliers = pd.DataFrame(np.zeros((len(Distances.index),len(Distances.columns))),
                    index = export_countries,
                    columns = import_countries)

num_carrier_2019_4_Suppliers = (transported_LNG_2019_4_Suppliers*10**9)/(0.94 * LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas - LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas * LNG_Carrier.loc[0, "Boil off"] * Time)*(Time+3)/365
num_carrier_2019_4_Suppliers.to_numpy().sum()

num_carrier_2019_5_Suppliers = pd.DataFrame(np.zeros((len(Distances.index),len(Distances.columns))),
                    index = export_countries,
                    columns = import_countries)

num_carrier_2019_5_Suppliers = (transported_LNG_2019_5_Suppliers*10**9)/(0.94 * LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas - LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas * LNG_Carrier.loc[0, "Boil off"] * Time)*(Time+3)/365
num_carrier_2019_5_Suppliers.to_numpy().sum()

Num_of_Carriers = [round(num_carrier_3.to_numpy().sum()),
                   round(num_carrier_2019_4_Suppliers.to_numpy().sum()),
                   round(num_carrier_2019_5_Suppliers.to_numpy().sum())]

Carriers_2019_Diversification  = pd.DataFrame(Num_of_Carriers,
                   index = ["3", "4", "5"],
                   columns = ["Average Number of Carriers"])

plt.rc('font', size=16)
plt.rc('axes', labelsize=16)
plt.rc('xtick', labelsize=16)
plt.rc('ytick', labelsize=16)

ax = Carriers_2019_Diversification.plot(figsize = (9, 6), kind="bar", color = "orange", rot=0, ylim=(0,410))
for container in ax.containers:
    ax.bar_label(container)

    
ax.set_xlabel("Minimal number of different LNG suppliers")
plt.legend(bbox_to_anchor=(1.0, 1.0))
ax.get_legend().remove()
plt.show()

###############################################################################
### 7.6 Total Costs
###############################################################################
Div_Total_Costs = [round(model_2019.Cost() / 10**9, 0),
               round(model_2019_4_Suppliers.Cost() / 10**9, 0),
               round(model_2019_5_Suppliers.Cost() / 10**9, 0)]

Diversification_Total_Costs = pd.DataFrame({#"Import Volumes": Imports_Outlook, 
                                    "Total Costs": Div_Total_Costs}, 
                                   index = ["3", "4", "5"])

ax = Diversification_Total_Costs.plot(figsize = (9, 6), kind="bar", color = [#"lightblue",
                                                                     "lightcoral"], rot=0, ylim=(0,120))

for container in ax.containers:
    ax.bar_label(container)
ax.set_ylabel("Billions of $")

plt.rc('font', size=16)
plt.rc('axes', labelsize=16)
        
plt.legend(bbox_to_anchor=(1.0, 1.0))
ax.get_legend().remove()
ax.set_xlabel("Minimal number of different LNG suppliers")
#ax.set_xlabel("Minimal number of different importing routes")
plt.show()

###############################################################################
### 7.7 Emissions
###############################################################################
Emissions_2019_4 = CO2_Emissions * (transported_LNG_2019_4_Suppliers*10**9) / (0.94 * LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas - LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas * LNG_Carrier.loc[0, "Boil off"] * Time)
Emissions_CO2_4 = round(Emissions_2019_4.to_numpy().sum()/10**6,2)

Emissions_2019_5 = CO2_Emissions * (transported_LNG_2019_5_Suppliers*10**9) / (0.94 * LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas - LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas * LNG_Carrier.loc[0, "Boil off"] * Time)
Emissions_CO2_5 = round(Emissions_2019_5.to_numpy().sum()/10**6,2)

Emi_Diver_CO2 = [Outlook_2019_CO2, Emissions_CO2_4, Emissions_CO2_5]

Emissions_Diver_CO2 = pd.DataFrame(Emi_Diver_CO2,
                   
                   index = ["3", "4", "5"],
    
                   columns = ["CO2 Emissions"])

plt.rc('font', size=16)
plt.rc('axes', labelsize=16)
ax = Emissions_Diver_CO2.plot(figsize = (9, 6), kind="bar", color = "lightgray", rot=0, ylim=(0,75))
for container in ax.containers:
    ax.bar_label(container)

ax.set_ylabel("megatonnes")    
plt.legend(bbox_to_anchor=(1.0, 1.0))
ax.get_legend().remove()
ax.set_xlabel("Minimal number of different LNG suppliers")
plt.show()

Emissions_2019_4_CH4 = CH4_Emissions * (transported_LNG_2019_4_Suppliers*10**9) / (0.94 * LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas - LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas * LNG_Carrier.loc[0, "Boil off"] * Time)
Emissions_CH4_4 = round(Emissions_2019_4_CH4.to_numpy().sum()/10**3,2)

Emissions_2019_5_CH4 = CH4_Emissions * (transported_LNG_2019_5_Suppliers*10**9) / (0.94 * LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas - LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas * LNG_Carrier.loc[0, "Boil off"] * Time)
Emissions_CH4_5 = round(Emissions_2019_5_CH4.to_numpy().sum()/10**3,2)

Emi_Diver_CH4 = [Outlook_2019_CH4, Emissions_CH4_4, Emissions_CH4_5]

Emissions_Diver_CH4 = pd.DataFrame(Emi_Diver_CH4,
                   
                   index = ["3", "4", "5"],
    
                   columns = ["CH4 Emissions"])


ax = Emissions_Diver_CH4.plot(figsize = (9, 6), kind="bar", color = "grey", rot=0, ylim=(0,47))
for container in ax.containers:
    ax.bar_label(container)

ax.set_ylabel("kilotonnes")    
plt.legend(bbox_to_anchor=(1.0, 1.0))
ax.get_legend().remove()
ax.set_xlabel("Minimal number of different LNG suppliers")
plt.show()

###############################################################################
### 8 Strait of Hormuz at 2/3
###############################################################################
### 8.1 Prices
###############################################################################
number_carriers = 3

model_2019_HC = create_and_solve_model(Demand_2019, Supply_HC, Cost, number_carriers)
CUS_2019 = list(Demand_2019.keys()) 
SRC_HC = list(Supply_HC.keys())

Import_2019_HC = [105.6*10**9 * MMBtu_Gas, 84.9*10**9 * MMBtu_Gas, 55.6*10**9 * MMBtu_Gas,
                         32.9*10**9 * MMBtu_Gas, 23.2*10**9 * MMBtu_Gas, 12.4*10**9 * MMBtu_Gas,
                         23.1*10**9 * MMBtu_Gas, 21.9*10**9 * MMBtu_Gas, 19.1*10**9 * MMBtu_Gas,
                         14.3*10**9 * MMBtu_Gas, 13.2*10**9 * MMBtu_Gas, 9*10**9 * MMBtu_Gas,
                         30.6*10**9 * MMBtu_Gas, 24.4*10**9 * MMBtu_Gas, 11.2*10**9 * MMBtu_Gas,
                         13.5*10**9 * MMBtu_Gas, 10.9*10**9 * MMBtu_Gas]
transported_2019_HC, DES_Price_2019_HC = calculate_model_results(
                                model_2019_HC, Total_Costs, Distances, "Base Year", Import_2019_HC)

Dual_Export_2019_HC = shadow_price_exp(model_2019_HC, SRC_HC)
Dual_Import_2019_HC = shadow_price_imp(model_2019_HC, CUS_2019)

###############################################################################
### 8.2 Costs
###############################################################################
Costs_HC = [round(Total_Costs_2019 / 10**9, 2),
            round(model_2019_HC.Cost() / 10**9, 2)]


Costs_HC_ = pd.DataFrame({"Total costs": Costs_HC, 
                              }, index = ["Baseline", "ME Output reduced by 33%"])


ax = Costs_HC_.plot(figsize = (9, 6), kind="bar", color = ["coral"], rot=0, ylim=(0,125))

for container in ax.containers:
    ax.bar_label(container)
    
plt.legend(bbox_to_anchor=(1.0, 1.0))
ax.set_ylabel("Billions of $")
ax.get_legend().remove()
plt.show()

###############################################################################
### 8.3 Number of LNG Carriers
###############################################################################
LNG_Carrier_Number_HC = pd.DataFrame(np.zeros((len(Distances.index),len(Distances.columns))),               
                    index = export_countries,
                    columns = import_countries)

LNG_Carrier_Number_HC = (transported_2019_HC*10**9)/(0.94 * LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas - LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas * LNG_Carrier.loc[0, "Boil off"] * Time)*(Time+3)/365

Num_of_Carriers_HC = [round(Carriers_2019),
                      round(LNG_Carrier_Number_HC.to_numpy().sum())]

Carriers_2019_HC = pd.DataFrame(Num_of_Carriers_HC,
                   index = ["Normal", "ME Output -33%"],
                   columns = ["Average Number of Carriers"])

ax = Carriers_2019_HC.plot(figsize = (9, 6), kind="bar", color = "orange", rot=0, ylim=(0,385))
for container in ax.containers:
    ax.bar_label(container)

#ax.set_xlabel("Minimal number of different LNG suppliers")
plt.legend(bbox_to_anchor=(1.0, 1.0))
ax.get_legend().remove()
plt.show()

###############################################################################
### 8.5 Emissions
###############################################################################
Emissions_2019_HC_ = CO2_Emissions * (transported_2019_HC*10**9) / (0.94 * LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas - LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas * LNG_Carrier.loc[0, "Boil off"] * Time)
Emissions_2019_HC_CO2 = round(Emissions_2019_HC_.to_numpy().sum()/10**6,2)


Emi_HC_CO2 = [Outlook_2019_CO2, Emissions_2019_HC_CO2]

Emissions_HC_CO2 = pd.DataFrame(Emi_HC_CO2,
                   
                   index = ["Baseline", "ME Output reduced by 33%"],
    
                   columns = ["CO2 Emissions"])


ax = Emissions_HC_CO2.plot(figsize = (9, 6), kind="bar", color = "lightgray", rot=0, ylim=(0,70))

for container in ax.containers:
    ax.bar_label(container)

ax.set_ylabel("megatonnes")    
plt.legend(bbox_to_anchor=(1.0, 1.0))
ax.get_legend().remove()
plt.show()

Emissions_2019_HC_CH4_ = CH4_Emissions * (transported_2019_HC*10**9) / (0.94 * LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas - LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas * LNG_Carrier.loc[0, "Boil off"] * Time)
Emissions_2019_HC_CH4 = round(Emissions_2019_HC_CH4_.to_numpy().sum()/10**3,2)


Emi_HC_CH4 = [Outlook_2019_CH4, Emissions_2019_HC_CH4]

Emissions_HC_CH4 = pd.DataFrame(Emi_HC_CH4,
                   
                   index = ["Baseline", "ME Output reduced by 33%"],
    
                   columns = ["CH4 Emissions"])


ax = Emissions_HC_CH4.plot(figsize = (9, 6), kind="bar", color = "grey", rot=0, ylim=(0,43))
for container in ax.containers:
    ax.bar_label(container)

ax.set_ylabel("kilotonnes")    
plt.legend(bbox_to_anchor=(1.0, 1.0))
ax.get_legend().remove()
plt.show()
Emissions_2019_HC_CH4

###############################################################################
### 9 Europe +33%
###############################################################################
### 9.1 DES Price
###############################################################################
number_carriers = 4

model_2019_EU = create_and_solve_model(Demand_2019_EU, Supply_2019, Cost, number_carriers)
CUS_EU = list(Demand_2019_EU.keys()) 
SRC_2019 = list(Supply_2019.keys())

Import_2019_EU = [105.6*10**9 * MMBtu_Gas, 84.9*10**9 * MMBtu_Gas, 55.6*10**9 * MMBtu_Gas,
                           32.9*10**9 * MMBtu_Gas, 23.2*10**9 * MMBtu_Gas, 12.4*10**9 * MMBtu_Gas,
                           (4/3)*23.1*10**9 * MMBtu_Gas, (4/3)*21.9*10**9 * MMBtu_Gas, (4/3)*19.1*10**9 * MMBtu_Gas,
                           (4/3)*14.3*10**9 * MMBtu_Gas, (4/3)*13.2*10**9 * MMBtu_Gas, (4/3)*9*10**9 * MMBtu_Gas,
                           30.6*10**9 * MMBtu_Gas, (4/3)*24.4*10**9 * MMBtu_Gas, 11.2*10**9 * MMBtu_Gas,
                           13.5*10**9 * MMBtu_Gas, 10.9*10**9 * MMBtu_Gas]
transported_LNG_2019_EU, DES_Price_2019_EU = calculate_model_results(
                                model_2019_EU, Total_Costs, Distances, "Base Year", Import_2019_EU)

Dual_Export_2019_EU = shadow_price_exp(model_2019_EU, SRC_2019)
Dual_Import_2019_EU = shadow_price_imp(model_2019_EU, CUS_EU)

###############################################################################
### 9.2 Carriers
###############################################################################
LNG_Carrier_Number_2019_EU = pd.DataFrame(np.zeros((len(Distances.index),len(Distances.columns))),            
                    index = export_countries,
                    columns = import_countries)

LNG_Carrier_Number_EU = (transported_LNG_2019_EU*10**9)/(0.94 * LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas - LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas * LNG_Carrier.loc[0, "Boil off"] * Time)*(Time+3)/365
Carriers_EU = round(LNG_Carrier_Number_EU.to_numpy().sum())

LNG_Carr_EU_ = [round(num_carrier_2019_4_Suppliers.to_numpy().sum()), Carriers_EU]

LNG_Carriers_EU = pd.DataFrame({"Number of LNG Carriers": LNG_Carr_EU_, 
                              }, index = ["Normal", "Europe +33% demand increase"])

ax = LNG_Carriers_EU.plot(figsize = (9, 6), kind="bar", color = ["orange"], rot=0, ylim=(0,438))

for container in ax.containers:
    ax.bar_label(container)
    
plt.legend(bbox_to_anchor=(1.0, 1.0))
ax.get_legend().remove()
plt.show()

###############################################################################
### 9.3 Costs
###############################################################################
Costs_EU = [round(model_2019_4_Suppliers.Cost() / 10**9, 2),
            round(model_2019_EU.Cost() / 10**9, 2)]


Costs_EU_ = pd.DataFrame({"Total costs": Costs_EU, 
                              }, index = ["Normal", "Europe +33% demand increase"])


ax = Costs_EU_.plot(figsize = (9, 6), kind="bar", color = ["coral"], rot=0, ylim=(0,130))

for container in ax.containers:
    ax.bar_label(container)
    
plt.legend(bbox_to_anchor=(1.0, 1.0))
ax.set_ylabel("Billions of $")
ax.get_legend().remove()
plt.show()

###############################################################################
### 9.6 CO2
###############################################################################
Emissions_2019_EU_ = CO2_Emissions * (transported_LNG_2019_EU*10**9) / (0.94 * LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas - LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas * LNG_Carrier.loc[0, "Boil off"] * Time)
Emissions_2019_EU_CO2 = round(Emissions_2019_EU_.to_numpy().sum()/10**6,2)


Emi_EU_CO2 = [Emissions_CO2_4, Emissions_2019_EU_CO2]

Emissions_EU_CO2 = pd.DataFrame(Emi_EU_CO2,
                   
                   index = ["Normal", "Europe +33% demand increase"],
    
                   columns = ["CO2 Emissions"])


ax = Emissions_EU_CO2.plot(figsize = (9, 6), kind="bar", color = "lightgray", rot=0, ylim=(0,79))

for container in ax.containers:
    ax.bar_label(container)

ax.set_ylabel("megatonnes")    
plt.legend(bbox_to_anchor=(1.0, 1.0))
ax.get_legend().remove()
plt.show()

###############################################################################
### 9.7 CH4
###############################################################################
Emissions_2019_EU_CH4_ = CH4_Emissions * (transported_LNG_2019_EU*10**9) / (0.94 * LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas - LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas * LNG_Carrier.loc[0, "Boil off"] * Time)
Emissions_2019_EU_CH4 = round(Emissions_2019_EU_CH4_.to_numpy().sum()/10**3,2)


Emi_EU_CH4 = [Emissions_CH4_4, Emissions_2019_EU_CH4]

Emissions_EU_CH4 = pd.DataFrame(Emi_EU_CH4,
                   
                   index = ["Normal", "Europe +33% demand increase"],
    
                   columns = ["CH4 Emissions"])


ax = Emissions_EU_CH4.plot(figsize = (9, 6), kind="bar", color = "grey", rot=0, ylim=(0,51))
for container in ax.containers:
    ax.bar_label(container)

ax.set_ylabel("kilotonnes")    
plt.legend(bbox_to_anchor=(1.0, 1.0))
ax.get_legend().remove()
plt.show()

###############################################################################
### 10 Asia Pacific -20%
###############################################################################
### 10.1 DES Price
###############################################################################
number_carriers = 4

model_2019_Asia = create_and_solve_model(Demand_2019_Asia, Supply_2019, Cost, number_carriers)
CUS_Asia = list(Demand_2019_Asia.keys()) 
SRC_2019 = list(Supply_2019.keys())

Import_2019_Asia = [1.121*105.6*10**9 * MMBtu_Gas, 1.121*84.9*10**9 * MMBtu_Gas, 1.121*55.6*10**9 * MMBtu_Gas,
                           1.121*32.9*10**9 * MMBtu_Gas, 1.121*23.2*10**9 * MMBtu_Gas, 1.121*12.4*10**9 * MMBtu_Gas,
                           23.1*10**9 * MMBtu_Gas, 21.9*10**9 * MMBtu_Gas, 19.1*10**9 * MMBtu_Gas,
                           14.3*10**9 * MMBtu_Gas, 13.2*10**9 * MMBtu_Gas, 9*10**9 * MMBtu_Gas,
                           1.121*30.6*10**9 * MMBtu_Gas, 24.4*10**9 * MMBtu_Gas, 11.2*10**9 * MMBtu_Gas,
                           13.5*10**9 * MMBtu_Gas, 10.9*10**9 * MMBtu_Gas]

transported_LNG_2019_Asia, DES_Price_2019_Asia = calculate_model_results(
                                model_2019_Asia, Total_Costs, Distances, "Base Year", Import_2019_Asia)

Dual_Export_2019_Asia = shadow_price_exp(model_2019_Asia, SRC_2019)
Dual_Import_2019_Asia = shadow_price_imp(model_2019_Asia, CUS_Asia)

###############################################################################
### 10.2 Carriers
###############################################################################
LNG_Carrier_Number_2019_AS = pd.DataFrame(np.zeros((len(Distances.index),len(Distances.columns))),
                    index = export_countries,
                    columns = import_countries)

LNG_Carrier_Number_AS = (transported_LNG_2019_Asia*10**9)/(0.94 * LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas - LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas * LNG_Carrier.loc[0, "Boil off"] * Time)*(Time+3)/365
Carriers_AS = round(LNG_Carrier_Number_AS.to_numpy().sum())

LNG_Carr_AS_ = [round(num_carrier_2019_4_Suppliers.to_numpy().sum()), Carriers_AS]


LNG_Carriers_AS = pd.DataFrame({"Number of LNG Carriers": LNG_Carr_AS_, 
                              }, index = ["Normal", "Asia Pacific 20% demand decrease"])

bx = LNG_Carriers_AS.plot(figsize = (9, 6), kind="bar", color = ["orange"], rot=0, ylim=(0,400))

for container in bx.containers:
    bx.bar_label(container)
    
plt.legend(bbox_to_anchor=(1.0, 1.0))
bx.get_legend().remove()
plt.show()
Carriers_AS

###############################################################################
### 10.3 Costs
###############################################################################
Costs_AS = [round(model_2019_4_Suppliers.Cost() / 10**9, 2),
            round(model_2019_Asia.Cost() / 10**9, 2)]

Costs_AS_ = pd.DataFrame({"Total costs": Costs_AS, 
                              }, index = ["Normal", "Asia Pacific 20% demand decrease%"])

ax = Costs_AS_.plot(figsize = (9, 6), kind="bar", color = ["coral"], rot=0, ylim=(0,120))

for container in ax.containers:
    ax.bar_label(container)
    
plt.legend(bbox_to_anchor=(1.0, 1.0))
ax.set_ylabel("Billions of $")
ax.get_legend().remove()
plt.show()

###############################################################################
### 10.6 CO2
###############################################################################
Emissions_2019_AS_ = CO2_Emissions * (transported_LNG_2019_Asia*10**9) / (0.94 * LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas - LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas * LNG_Carrier.loc[0, "Boil off"] * Time)
Emissions_2019_AS_CO2 = round(Emissions_2019_AS_.to_numpy().sum()/10**6,2)

Emi_AS_CO2 = [Emissions_CO2_4, Emissions_2019_AS_CO2]

Emissions_AS_CO2 = pd.DataFrame(Emi_AS_CO2,    
                   index = ["Normal", "Asia Pacific 20% demand decrease"],   
                   columns = ["CO2 Emissions"])

ax = Emissions_AS_CO2.plot(figsize = (9, 6), kind="bar", color = "lightgray", rot=0, ylim=(0,69))

for container in ax.containers:
    ax.bar_label(container)

ax.set_ylabel("megatonnes")    
plt.legend(bbox_to_anchor=(1.0, 1.0))
ax.get_legend().remove()
plt.show()

###############################################################################
### 10.7 CH4
###############################################################################
Emissions_2019_AS_CH4_ = CH4_Emissions * (transported_LNG_2019_Asia*10**9) / (0.94 * LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas - LNG_Carrier.loc[0, "Capacity (m³)"] * LNG_to_Gas * LNG_Carrier.loc[0, "Boil off"] * Time)
Emissions_2019_AS_CH4 = round(Emissions_2019_AS_CH4_.to_numpy().sum()/10**3,2)

Emi_AS_CH4 = [Emissions_CH4_4, Emissions_2019_AS_CH4]

Emissions_AS_CH4 = pd.DataFrame(Emi_AS_CH4,                   
                   index = ["Normal", "Asia Pacific 20% demand decrease"],   
                   columns = ["CH4 Emissions"])

ax = Emissions_AS_CH4.plot(figsize = (9, 6), kind="bar", color = "grey", rot=0, ylim=(0,44))
for container in ax.containers:
    ax.bar_label(container)

ax.set_ylabel("kilotonnes")    
plt.legend(bbox_to_anchor=(1.0, 1.0))
ax.get_legend().remove()
plt.show()
