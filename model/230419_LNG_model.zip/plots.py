import shutil
import sys
import os.path
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import chart_studio
import chart_studio.plotly as py
import seaborn as sns
import chart_studio.plotly as py
from plotly.offline import download_plotlyjs, init_notebook_mode, plot, iplot
import folium
from folium.plugins import MarkerCluster
import json

from IPython.display import display
from geopy.geocoders import Nominatim
from geopy import distance
from pyomo.environ import *

###############################################################################
### init parameters
###############################################################################
geolocator = Nominatim(user_agent="Your_Name")

#pd.set_option('precision', 3)
MMBtu_LNG = 23.12 # 1m³ of LNG = 21.04MMBtu
MMBtu_Gas = 0.036 # 1m³ of Gas = 0.036MMBtu
LNG_to_Gas = 584 # 1m³ of LNG = 584m³ of gas (IGU LNG Annual Report 2019)
mt_LNG_BCM = 1.379 * 10**9 # mega tonne of LNG to bcm (https://www.enerdynamics.com/Energy-Currents_Blog/Understanding-Liquefied-Natural-Gas-LNG-Units.aspx)
mt_MMBtu = mt_LNG_BCM * MMBtu_Gas
t_oil_MMBtu = 39.6526 #  tonne of oil to mmbtu             https://unitjuggler.com/

import_countries = ["Japan", "China", "South Korea", "India", "Taiwan", 
                    "Pakistan", "France", "Spain","UK", "Italy", "Turkey", 
                    "Belgium", "Other Asia Pacific", "Other Europe",
                    "Total North America", "Total S. & C. America", 
                    "Total ME & Africa"
                    ]

export_countries = ["Qatar", "Australia", "USA", "Russia", "Malaysia", 
                    "Nigeria", "Trinidad & Tobago", "Algeria", "Indonesia", 
                    "Oman", "Other Asia Pacific", "Other Europe", 
                    "Other Americas", "Other ME", "Other Africa"
                    ]

def plot_map(Imp_Nodes, Exp_Nodes):
    m = folium.Map(location=Exp_Nodes[["Latitude", "Longitude"]].mean().to_list(), zoom_start=1.5)
    #marker_cluster = MarkerCluster().add_to(m)

    for i,r in Exp_Nodes.iterrows():
        location = (r["Latitude"], r["Longitude"])
        folium.Marker(location=location,
                          popup = r['Country'],
                          tooltip=r['Country'],
                      icon = folium.Icon(color='orange')).add_to(m)
        
    for i,r in Imp_Nodes.iterrows():
        location = (r["Latitude"], r["Longitude"])
        folium.Marker(location=location,
                      popup = r['Country'],
                      tooltip=r['Country'],
                      icon = folium.Icon(color='blue')).add_to(m)
                                                            
    # display the map
    folium.Choropleth(
        geo_data=us_states,
        name='choropleth',
        data=Exp_Nodes,
        columns=['Country', "Nominal Liquefaction Capacity 2019 (MMBtu)"],
        key_on='feature.id',
        fill_color='YlGn',
        fill_opacity=0.7,
        line_opacity=0.2,
        #legend_name='Unemployment Rate %'
    ).add_to(m)
    
    return